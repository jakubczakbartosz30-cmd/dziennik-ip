DZIENNIK IP — GOTOWY ZESTAW

Pliki, które muszą być w KORZENIU repozytorium GitHub:
- index.html
- app.js
- styles.css
- manifest.json

Ważne:
1. Nie wrzucaj tych plików do dodatkowego folderu.
2. Po wrzuceniu wszystkich czterech plików Vercel powinien wykryć index.html.
3. Vercel ma być podłączony do repozytorium `dziennik-ip` i gałęzi `main`.
4. Otwórz domenę projektu po zakończeniu Deployment.

Aplikacja działa jako statyczna strona i zapisuje wpisy zabiegów w pamięci przeglądarki (localStorage).
