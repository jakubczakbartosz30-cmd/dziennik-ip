const KEY="dziennik-ip-data";
const seed={plots:[{id:1,name:"Kwatera 1",crop:"Jabłoń",area:"2,40 ha"},{id:2,name:"Kwatera 2",crop:"Grusza",area:"1,80 ha"}],sprays:[]};
let data=JSON.parse(localStorage.getItem(KEY)||"null")||seed;
let page="home";
const save=()=>localStorage.setItem(KEY,JSON.stringify(data));
const content=document.querySelector("#content");
function nav(){document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page))}
function render(){
 nav();
 if(page==="home") content.innerHTML=`<section class="hero"><h2>Dzień dobry 👋</h2><p class="muted">Twój cyfrowy dziennik ochrony roślin.</p><button class="btn" onclick="page='sprays';render()">+ Dodaj zabieg</button></section>
 <div class="grid"><div class="card">🌳 Kwatery<b>${data.plots.length}</b></div><div class="card">🧪 Zabiegi<b>${data.sprays.length}</b></div></div>
 <h3 class="section-title">Ostatnie zabiegi</h3>${data.sprays.length?`<div class="list">${data.sprays.slice(-3).reverse().map(s=>row(s)).join("")}</div>`:`<div class="empty">Brak zapisanych zabiegów.</div>`}`;
 if(page==="farm") content.innerHTML=`<div class="hero"><h2>Gospodarstwo</h2><p class="muted">Kwatery i podstawowe dane upraw.</p><button class="btn secondary" onclick="addPlot()">+ Dodaj kwaterę</button></div><div class="map"><span class="plot p1">K1</span><span class="plot p2">K2</span><span class="plot p3">K3</span></div><h3 class="section-title">Kwatery</h3><div class="list">${data.plots.map(p=>`<div class="row"><div><b>${p.name}</b><br><span class="muted">${p.crop} · ${p.area}</span></div><span class="badge">Aktywna</span></div>`).join("")}</div>`;
 if(page==="sprays") content.innerHTML=`<h2>Dodaj zabieg</h2><form class="form" onsubmit="addSpray(event)"><label>Data<input id="date" type="date" required value="${new Date().toISOString().slice(0,10)}"></label><label>Kwatera<select id="plot">${data.plots.map(p=>`<option>${p.name}</option>`).join("")}</select></label><label>Uprawa<input id="crop" placeholder="np. jabłoń" required></label><label>Środek ochrony roślin<input id="product" placeholder="Nazwa środka" required></label><label>Dawka<input id="dose" placeholder="np. 0,5 l/ha" required></label><label>Cel zabiegu<textarea id="target" placeholder="np. parch"></textarea></label><button class="btn">Zapisz zabieg</button></form>`;
 if(page==="history") content.innerHTML=`<h2>Historia zabiegów</h2><p class="muted">Wszystkie zapisane zabiegi.</p>${data.sprays.length?`<div class="list">${data.sprays.slice().reverse().map(s=>row(s,true)).join("")}</div>`:`<div class="empty">Historia jest pusta.</div>`}`;
}
function row(s){return `<div class="row"><div><b>${s.product}</b><br><span class="muted">${s.date} · ${s.plot}</span><br><span>${s.dose}${s.target?" · "+s.target:""}</span></div><span class="badge">Zabieg</span></div>`}
function addSpray(e){e.preventDefault();data.sprays.push({date:date.value,plot:plot.value,crop:crop.value,product:product.value,dose:dose.value,target:target.value});save();page="history";render()}
function addPlot(){const name=prompt("Nazwa kwatery","Kwatera "+(data.plots.length+1));if(!name)return;const crop=prompt("Uprawa","Jabłoń")||"";const area=prompt("Powierzchnia","1,00 ha")||"";data.plots.push({id:Date.now(),name,crop,area});save();render()}
document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>{page=b.dataset.page;render()});
document.querySelector("#profile").onclick=()=>alert("Profil użytkownika — podłączymy logowanie Supabase w kolejnym etapie.");
render();