# Dziennik IP

Pierwsza działająca wersja mobilnego systemu:
- pulpit gospodarstwa
- kwatery z prostą mapą
- dodawanie zabiegów
- historia zabiegów
- zapis danych lokalnie w przeglądarce
- przygotowanie pod PWA

## Następny etap
Podłączenie Supabase: logowanie, użytkownicy, gospodarstwa, kwatery i trwały zapis zabiegów.
